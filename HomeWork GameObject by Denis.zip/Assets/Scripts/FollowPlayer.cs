﻿using UnityEngine;

public class FollowPlayer : MonoBehaviour
{
    public Transform plane;
    public float smoothSpeed = 0.125f;
    public float distance = 5f;
    public float height = 2f;
    public Vector3 offset;

    // Update is called once per frame
    void FixedUpdate()
    {
        Vector3 desiredPosition = plane.position - plane.forward * distance + Vector3.up * height;
        Vector3 smoothPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed);

        transform.position = smoothPosition;

        transform.LookAt(plane);
    }
}
