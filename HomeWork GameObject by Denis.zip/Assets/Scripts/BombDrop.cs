using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BombDrop : MonoBehaviour
{
    public GameObject bomb;

    // Update is called once per frame
    void Start()
    {
        bomb.SetActive(false);
    }
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space)) 
        {
            GameObject bombClone = Instantiate(bomb, transform.position, transform.rotation);
            bombClone.SetActive(true);
            
            Destroy(bombClone, 5);
        }

    }
}
