using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PropellerRotation : MonoBehaviour
{
    public int rotationSpeed = 10;
   
   public GameObject propeller; 
    // Update is called once per frame
    void Update()
    {
       propeller.transform.Rotate(0f , 0f , rotationSpeed);
       
    }
}
